
package model;


public interface IMembers {

	public void setName(String name);
	public String getName();
	
	public void setPersonalNumber(String personalNumber);
	public String getPersonalNumber();
	
	public void setMemberID(int memberID);
	public int getMemberID();
	
	
}
