import java.io.IOException;

import view.Console;

public class Program {
	public static void main(String[] args) throws IOException, InterruptedException  {
		
		
		Console consloe = new Console();
		
		consloe.welcomeWindow();
		
	}
}
